<?php
    /*const SERVER = 'mysql219.phy.lolipop.lan';
    const DBNAME = 'LAA1518091-cosmeshop';
    const USER = 'LAA1518091';
    const PASS = 'Pass0802';*/
    const SERVER = 'mysql218.phy.lolipop.lan';
    const DBNAME = 'LAA1518091-teamgirls';
    const USER = 'LAA1518091';
    const PASS = 'Pass0802';

    $connect = 'mysql:host='. SERVER . ';dbname='. DBNAME . ';charset=utf8';
?>