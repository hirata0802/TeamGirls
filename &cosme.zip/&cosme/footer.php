</body>
</html>
<?php
 $pdo = null;   //DB切断
 ?>