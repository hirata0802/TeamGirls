<?php session_start(); ?>
<?php require 'header.php'; ?>
<?php require 'menu.php'; ?>
<?php require 'db_connect.php'; ?>
<div id="logtitle"><h2>カート</h2></div>
<div id="mannaka">カートに商品がありません</div>
<?php require 'footer.php'; ?>
