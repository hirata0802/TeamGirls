<?php require 'header.php'; ?>
    <h3>&cosme</h3>
    <h2>ログアウト</h2>
    <hr color="black">
    <form action="k_logout_finish.php" method="post">
    <div id="logtitle2"><h3>ログアウトしますか？</h3></div>
    <p><button class="ao" type="submit">ログアウト</button></p></div>
    <div hr1><hr width="250"></div>
    <br>
    <div id="mannaka"><a href="k_home.php">＞ホームへ</a></div>
</form>
</body>
</html>